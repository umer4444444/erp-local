const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const StockLog = sequelize.define('StockLog', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  productId: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  change: {
    type: DataTypes.INTEGER,
  },
  type: {
    type: DataTypes.ENUM('sale', 'restock', 'adjustment', 'return', 'void', 'prescription'),
  },
  notes: {
    type: DataTypes.STRING,
  },
  reference: {
    type: DataTypes.UUID,
    allowNull: true,
  },
}, {
  timestamps: true,
});

module.exports = StockLog;
