const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Product = sequelize.define('Product', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  sku: {
    type: DataTypes.STRING,
    unique: true,
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  costPrice: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
  stock: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  categoryId: {
    type: DataTypes.UUID,
  },
  storeType: {
    type: DataTypes.ENUM('department', 'pharmacy'),
    defaultValue: 'department',
  },
  expiryDate: {
    type: DataTypes.DATEONLY,
  },
  manufacturer: {
    type: DataTypes.STRING,
  },
}, {
  timestamps: true,
});

module.exports = Product;
